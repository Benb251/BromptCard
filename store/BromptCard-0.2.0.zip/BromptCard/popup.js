import { PROVIDER_LIST, DEFAULT_PROVIDER_ID } from "./providers/index.js";

const I18N = {
  vi: {
    heading: "Browser AI",
    intro: "Phân tích ảnh thành prompt có cấu trúc bằng tab chat AI bạn đã đăng nhập. Không cần API key, không tài khoản, không backend.",
    hint: "Mở provider ở một tab khác và đăng nhập. BromptCard gửi ảnh vào tab đó và đọc phản hồi.",
    providerLabel: "Provider",
    save: "Lưu",
    checkTab: "Kiểm tra tab",
    openProvider: "Mở tab provider",
    openPanel: "Mở panel trên tab hiện tại",
    upgrade: "Nâng cấp Pro",
    planPro: "Pro - không giới hạn",
    planFree: "Miễn phí - còn {n}/{limit} lượt hôm nay",
    upgradeFailed: "Không mở được trang nâng cấp.",
    checking: "Đang kiểm tra tab provider...",
    statusReadable: "Không đọc được trạng thái provider.",
    tabReady: (name) => `Tab ${name} đang mở và sẵn sàng.`,
    tabNotOpen: (name) => `Tab ${name} chưa mở. Hãy mở và đăng nhập.`,
    saved: "Đã lưu cài đặt.",
    saveFailed: "Không thể lưu cài đặt.",
    unknownProvider: "Provider không xác định.",
    opened: (name) => `Đã mở ${name}. Đăng nhập rồi chạy phân tích.`,
    openProviderFailed: "Không thể mở tab provider.",
    panelOpened: "Đã mở panel trên tab hiện tại.",
    openPanelFailed: "Không thể mở panel.",
    loadFailed: "Không thể tải cài đặt.",
    timedOut: (type) => `Hết thời gian chờ ${type}. Hãy tải lại tiện ích và thử lại.`
  },
  en: {
    heading: "Browser AI",
    intro: "Analyze images into structured prompts using your logged-in AI chat tab. No API key, no account, no hosted backend.",
    hint: "Open the provider in another tab and sign in. BromptCard sends the image to that tab and reads the reply.",
    providerLabel: "Provider",
    save: "Save",
    checkTab: "Check tab",
    openProvider: "Open provider tab",
    openPanel: "Open panel on active tab",
    upgrade: "Upgrade to Pro",
    planPro: "Pro - unlimited",
    planFree: "Free - {n}/{limit} uses left today",
    upgradeFailed: "Could not open the upgrade page.",
    checking: "Checking provider tab...",
    statusReadable: "Could not read provider status.",
    tabReady: (name) => `${name} tab is open and ready.`,
    tabNotOpen: (name) => `${name} tab is not open. Open it and sign in.`,
    saved: "Settings saved.",
    saveFailed: "Could not save settings.",
    unknownProvider: "Unknown provider.",
    opened: (name) => `Opened ${name}. Sign in, then run analysis.`,
    openProviderFailed: "Could not open provider tab.",
    panelOpened: "Panel opened on the active tab.",
    openPanelFailed: "Could not open the panel.",
    loadFailed: "Could not load settings.",
    timedOut: (type) => `Request timed out while waiting for ${type}. Reload the extension and try again.`
  }
};

let lang = "vi";
function t(key, arg) {
  const table = I18N[lang] || I18N.vi;
  const value = table[key] != null ? table[key] : I18N.vi[key];
  return typeof value === "function" ? value(arg) : value;
}

function applyStaticI18n() {
  document.documentElement.lang = lang;
  document.querySelectorAll("[data-i18n]").forEach((node) => {
    node.textContent = t(node.getAttribute("data-i18n"));
  });
}

const providerSelect = document.getElementById("provider");
const statusBox = document.getElementById("status");
const saveButton = document.getElementById("saveButton");
const checkButton = document.getElementById("checkButton");
const openProviderButton = document.getElementById("openProviderButton");
const openPanelButton = document.getElementById("openPanelButton");
const message = document.getElementById("message");
const planBox = document.getElementById("plan");
const planState = document.getElementById("planState");
const upgradeButton = document.getElementById("upgradeButton");

function setMessage(text, type = "") {
  message.textContent = text;
  message.className = `message${type ? ` is-${type}` : ""}`;
}

function setStatus(text, type = "") {
  statusBox.textContent = text;
  statusBox.className = `status${type ? ` is-${type}` : ""}`;
}

function setBusy(isBusy) {
  saveButton.disabled = isBusy;
  checkButton.disabled = isBusy;
  openProviderButton.disabled = isBusy;
  openPanelButton.disabled = isBusy;
  if (upgradeButton) {
    upgradeButton.disabled = isBusy;
  }
}

function fillProviders() {
  providerSelect.innerHTML = "";
  for (const provider of PROVIDER_LIST) {
    const option = document.createElement("option");
    option.value = provider.id;
    option.textContent = provider.name;
    providerSelect.appendChild(option);
  }
}

async function rpc(type, payload) {
  return Promise.race([
    chrome.runtime.sendMessage({ type, payload }),
    new Promise((_, reject) => {
      setTimeout(() => {
        reject(new Error(t("timedOut", type)));
      }, 20000);
    })
  ]);
}

function selectedProvider() {
  return providerSelect.value || DEFAULT_PROVIDER_ID;
}

async function loadSettings() {
  const response = await rpc("PROMPTCARD_GET_SETTINGS");
  const settings = response?.data?.settings || {};
  lang = settings.language === "en" ? "en" : "vi";
  applyStaticI18n();
  providerSelect.value = settings.provider || DEFAULT_PROVIDER_ID;
  await refreshStatus();
}

async function refreshStatus() {
  setStatus(t("checking"));
  try {
    const response = await rpc("PROMPTCARD_PROVIDER_STATUS", { provider: selectedProvider() });
    if (!response?.ok) {
      throw new Error(response?.error || t("statusReadable"));
    }
    const status = response.data.status;
    if (status.open) {
      setStatus(t("tabReady", status.providerName), "success");
    } else {
      setStatus(t("tabNotOpen", status.providerName), "warn");
    }
  } catch (error) {
    setStatus(error instanceof Error ? error.message : t("statusReadable"), "error");
  }
}

async function saveSettings() {
  setBusy(true);
  setMessage("");
  try {
    const response = await rpc("PROMPTCARD_SAVE_SETTINGS", { provider: selectedProvider() });
    if (!response?.ok) {
      throw new Error(response?.error || t("saveFailed"));
    }
    setMessage(t("saved"), "success");
    await refreshStatus();
  } catch (error) {
    setMessage(error instanceof Error ? error.message : t("saveFailed"), "error");
  } finally {
    setBusy(false);
  }
}

async function openProviderTab() {
  setBusy(true);
  setMessage("");
  try {
    const provider = PROVIDER_LIST.find((item) => item.id === selectedProvider());
    if (!provider) {
      throw new Error(t("unknownProvider"));
    }
    await chrome.tabs.create({ url: provider.homeUrl, active: true });
    setMessage(t("opened", provider.name), "success");
  } catch (error) {
    setMessage(error instanceof Error ? error.message : t("openProviderFailed"), "error");
  } finally {
    setBusy(false);
  }
}

async function openPanel() {
  setBusy(true);
  setMessage("");
  try {
    const response = await rpc("PROMPTCARD_OPEN_ACTIVE_PANEL");
    if (!response?.ok) {
      throw new Error(response?.error || t("openPanelFailed"));
    }
    setMessage(t("panelOpened"), "success");
  } catch (error) {
    setMessage(error instanceof Error ? error.message : t("openPanelFailed"), "error");
  } finally {
    setBusy(false);
  }
}

async function refreshPlan() {
  try {
    const response = await rpc("PROMPTCARD_GET_QUOTA");
    if (!response?.ok || !response.data?.quota) {
      return;
    }
    const q = response.data.quota;
    planBox.hidden = false;
    if (q.pro || q.remaining === Infinity) {
      planState.textContent = t("planPro");
      upgradeButton.hidden = true;
    } else {
      planState.textContent = t("planFree").replace("{n}", q.remaining).replace("{limit}", q.limit);
      upgradeButton.hidden = false;
    }
  } catch {
    /* plan display is best-effort */
  }
}

async function openUpgrade() {
  setBusy(true);
  try {
    const response = await rpc("PROMPTCARD_OPEN_PAYMENT");
    if (!response?.ok) {
      throw new Error(response?.error || t("upgradeFailed"));
    }
    if (response.data && response.data.billingEnabled === false) {
      setMessage(t("upgradeFailed"), "warn");
    }
  } catch (error) {
    setMessage(error instanceof Error ? error.message : t("upgradeFailed"), "error");
  } finally {
    setBusy(false);
  }
}

fillProviders();
applyStaticI18n();
saveButton.addEventListener("click", saveSettings);
checkButton.addEventListener("click", refreshStatus);
openProviderButton.addEventListener("click", openProviderTab);
openPanelButton.addEventListener("click", openPanel);
providerSelect.addEventListener("change", refreshStatus);
upgradeButton.addEventListener("click", openUpgrade);

loadSettings().catch((error) => {
  setMessage(error instanceof Error ? error.message : t("loadFailed"), "error");
});
refreshPlan();
