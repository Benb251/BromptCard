import { MENU_ID } from "./constants.js";
import { AnalysisError } from "./lib/schema.js";
import { analyzeWithProvider, statusForProvider } from "./automation/orchestrator.js";
import { getSettings, saveSettings } from "./storage.js";
import { ensureAllowed, consume, getQuota, setPro, QuotaError } from "./lib/entitlement.js";
import { startBilling, syncProStatus, openPaymentPage, openTrialPage, billingEnabled } from "./lib/billing.js";

// Bump this token whenever every saved setting/preference should be wiped back
// to defaults on the next load. The reset runs exactly once per token.
const RESET_TOKEN = "reset-2026-06-01";
const RESET_TOKEN_KEY = "pcResetToken";

async function resetDefaultsOnce() {
  try {
    const stored = await chrome.storage.local.get(RESET_TOKEN_KEY);
    if (stored[RESET_TOKEN_KEY] === RESET_TOKEN) {
      return;
    }
    await chrome.storage.local.clear();
    await chrome.storage.local.set({ [RESET_TOKEN_KEY]: RESET_TOKEN });
  } catch (error) {
    // Storage might be briefly unavailable; ignore and retry on next load.
  }
}

function createContextMenu() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_ID,
      title: "Analyze image with BromptCard",
      contexts: ["image", "page"]
    });
  });
}

async function sendToTab(tabId, message) {
  return chrome.tabs.sendMessage(tabId, message);
}

async function ensurePanel(tabId, payload) {
  try {
    await sendToTab(tabId, {
      type: "PROMPTCARD_OPEN_PANEL",
      payload
    });
  } catch {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content.js"]
    });
    await sendToTab(tabId, {
      type: "PROMPTCARD_OPEN_PANEL",
      payload
    });
  }
}

async function captureVisibleTab(windowId) {
  return chrome.tabs.captureVisibleTab(windowId, { format: "png" });
}

function ok(sendResponse, data) {
  sendResponse({ ok: true, data });
}

chrome.runtime.onInstalled.addListener(() => {
  resetDefaultsOnce();
  createContextMenu();
  syncProStatus();
});
chrome.runtime.onStartup.addListener(() => {
  resetDefaultsOnce();
  createContextMenu();
  syncProStatus();
});

// Also runs when the service worker first wakes up after a reload.
resetDefaultsOnce();

// Billing: start ExtPay messaging and mirror paid status into entitlement.
startBilling();
syncProStatus();

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== MENU_ID || !tab?.id) {
    return;
  }

  const payload = info.srcUrl
    ? {
        srcUrl: info.srcUrl,
        pageUrl: info.pageUrl || tab.url || "",
        startMode: "image"
      }
    : {
        startMode: "screenshot",
        pageUrl: info.pageUrl || tab.url || ""
      };

  await ensurePanel(tab.id, payload);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "PROMPTCARD_RUN_ANALYSIS") {
    (async () => {
      try {
        const settings = await getSettings();
        const providerId = message.payload?.provider || settings.provider;
        const mode = message.payload?.mode || "analyze";
        await ensureAllowed(mode);
        const analysis = await analyzeWithProvider(providerId, message.payload.target, mode);
        await consume(mode);
        const quota = await getQuota();
        ok(sendResponse, { analysis, quota });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Analysis failed.",
          code:
            error instanceof QuotaError
              ? error.code
              : error instanceof AnalysisError
                ? error.code
                : "ANALYSIS_FAILED",
          quota: error instanceof QuotaError ? error.quota : undefined
        });
      }
    })();
    return true;
  }

  if (message?.type === "PROMPTCARD_OPEN_PAYMENT") {
    (async () => {
      try {
        const opened = await openPaymentPage();
        ok(sendResponse, { opened, billingEnabled: billingEnabled() });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Could not open the payment page."
        });
      }
    })();
    return true;
  }

  if (message?.type === "PROMPTCARD_OPEN_TRIAL") {
    (async () => {
      try {
        const opened = await openTrialPage();
        ok(sendResponse, { opened, billingEnabled: billingEnabled() });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Could not open the trial page."
        });
      }
    })();
    return true;
  }

  if (message?.type === "PROMPTCARD_SYNC_PRO") {
    (async () => {
      try {
        await syncProStatus();
        ok(sendResponse, { quota: await getQuota(), billingEnabled: billingEnabled() });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Could not sync Pro status."
        });
      }
    })();
    return true;
  }

  if (message?.type === "PROMPTCARD_GET_QUOTA") {
    (async () => {
      try {
        ok(sendResponse, { quota: await getQuota() });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Could not read quota."
        });
      }
    })();
    return true;
  }

  if (message?.type === "PROMPTCARD_SET_PRO") {
    (async () => {
      try {
        await setPro(Boolean(message.payload?.pro));
        ok(sendResponse, { quota: await getQuota() });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Could not update Pro state."
        });
      }
    })();
    return true;
  }

  if (message?.type === "PROMPTCARD_PROVIDER_STATUS") {
    (async () => {
      try {
        const settings = await getSettings();
        const providerId = message.payload?.provider || settings.provider;
        const status = await statusForProvider(providerId);
        ok(sendResponse, { status });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Could not read provider status."
        });
      }
    })();
    return true;
  }

  if (message?.type === "PROMPTCARD_GET_SETTINGS") {
    (async () => {
      ok(sendResponse, { settings: await getSettings() });
    })();
    return true;
  }

  if (message?.type === "PROMPTCARD_SAVE_SETTINGS") {
    (async () => {
      try {
        const settings = await saveSettings(message.payload || {});
        ok(sendResponse, { settings });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Could not save settings."
        });
      }
    })();
    return true;
  }

  if (message?.type === "PROMPTCARD_CAPTURE_VISIBLE_TAB") {
    (async () => {
      try {
        const dataUrl = await captureVisibleTab(sender.tab?.windowId);
        ok(sendResponse, { dataUrl });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Could not capture the visible tab."
        });
      }
    })();
    return true;
  }

  if (message?.type === "PROMPTCARD_OPEN_ACTIVE_PANEL") {
    (async () => {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab?.id) {
          throw new Error("Could not find the active tab.");
        }
        await ensurePanel(tab.id, {
          startMode: "panel",
          pageUrl: tab.url || ""
        });
        ok(sendResponse, { opened: true });
      } catch (error) {
        sendResponse({
          ok: false,
          error: error instanceof Error ? error.message : "Could not open the panel."
        });
      }
    })();
    return true;
  }

  return false;
});
