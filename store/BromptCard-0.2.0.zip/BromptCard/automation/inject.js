export function injectedAutomation(config) {
  const { base64, mimeType, promptText, selectors, timing, skipImage } = config;

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function isVisible(node) {
    if (!node) {
      return false;
    }
    const rect = node.getBoundingClientRect();
    const style = window.getComputedStyle(node);
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
  }

  function pickVisible(list) {
    for (const selector of list) {
      for (const node of document.querySelectorAll(selector)) {
        if (isVisible(node)) {
          return node;
        }
      }
    }
    return null;
  }

  function pickAny(list) {
    for (const selector of list) {
      const node = document.querySelector(selector);
      if (node) {
        return node;
      }
    }
    return null;
  }

  function isDisabled(button) {
    if (!button) {
      return true;
    }
    if (button.disabled) {
      return true;
    }
    if (button.getAttribute("aria-disabled") === "true") {
      return true;
    }
    if (/(^|\s)(disabled|mat-mdc-button-disabled)(\s|$)/.test(button.className || "")) {
      return true;
    }
    return false;
  }

  function buttonHasIcon(button, icons) {
    if (!icons || !icons.length) {
      return false;
    }
    const iconNodes = button.querySelectorAll("mat-icon, .material-icons, .material-symbols-outlined, [data-mat-icon-name]");
    for (const icon of iconNodes) {
      const name = (icon.getAttribute("data-mat-icon-name") || icon.getAttribute("fonticon") || icon.textContent || "")
        .trim()
        .toLowerCase();
      if (icons.some((wanted) => name === wanted || name.includes(wanted))) {
        return true;
      }
    }
    return false;
  }

  function findButton(list, icons, { visibleOnly = true } = {}) {
    const direct = visibleOnly ? pickVisible(list) : pickAny(list);
    if (direct) {
      return direct;
    }
    if (icons && icons.length) {
      for (const button of document.querySelectorAll("button")) {
        if ((!visibleOnly || isVisible(button)) && buttonHasIcon(button, icons)) {
          return button;
        }
      }
    }
    return null;
  }

  async function waitFor(fn, timeoutMs, pollMs) {
    const deadline = Date.now() + timeoutMs;
    for (;;) {
      const value = fn();
      if (value) {
        return value;
      }
      if (Date.now() > deadline) {
        return null;
      }
      await sleep(pollMs);
    }
  }

  function base64ToBlob(b64, type) {
    const binary = atob(b64);
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let index = 0; index < len; index += 1) {
      bytes[index] = binary.charCodeAt(index);
    }
    return new Blob([bytes], { type: type || "image/png" });
  }

  function readEditorText(editor) {
    if (!editor) {
      return "";
    }
    if (editor.value !== undefined && editor.tagName === "TEXTAREA") {
      return String(editor.value || "").trim();
    }
    return (editor.innerText || editor.textContent || "").trim();
  }

  function nonSpaceLen(value) {
    const matches = String(value || "").match(/\S/g);
    return matches ? matches.length : 0;
  }

  function escapeHtml(value) {
    return String(value || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function pasteText(editor, text) {
    const dataTransfer = new DataTransfer();
    dataTransfer.setData("text/plain", text);
    const html = String(text)
      .split("\n")
      .map((line) => (line.length ? `<p>${escapeHtml(line)}</p>` : "<p><br></p>"))
      .join("");
    dataTransfer.setData("text/html", html);
    editor.focus();
    const pasteEvent = new ClipboardEvent("paste", { bubbles: true, cancelable: true });
    try {
      Object.defineProperty(pasteEvent, "clipboardData", { value: dataTransfer });
    } catch {
      /* some engines lock clipboardData; ignore */
    }
    editor.dispatchEvent(pasteEvent);
  }

  function clearEditor(editor) {
    try {
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(editor);
      selection.removeAllRanges();
      selection.addRange(range);
      document.execCommand("delete", false);
    } catch {
      /* ignore */
    }
    if (readEditorText(editor).length > 0) {
      editor.innerHTML = "";
    }
  }

  function setEditorText(editor, text) {
    editor.focus();

    // Rich editors (Gemini uses Quill) truncate a pasted string at the first
    // newline, so multi-line prompts only land their first line. Flatten the
    // prompt to a single line; the model reads it the same.
    const flat = String(text).replace(/\s*\n+\s*/g, "  ").trim();

    if (editor.tagName === "TEXTAREA") {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value");
      if (setter && setter.set) {
        setter.set.call(editor, text);
      } else {
        editor.value = text;
      }
      editor.dispatchEvent(new InputEvent("input", { bubbles: true }));
      editor.dispatchEvent(new Event("change", { bubbles: true }));
      return;
    }

    const target = nonSpaceLen(flat);
    const enough = () => nonSpaceLen(readEditorText(editor)) >= Math.floor(target * 0.8);

    // Strategy 1: paste event (single line). Works in background tabs.
    clearEditor(editor);
    try {
      pasteText(editor, flat);
    } catch {
      /* fall through */
    }
    if (enough()) {
      return;
    }

    // Strategy 2: execCommand insertText (works when the document has focus).
    clearEditor(editor);
    try {
      const inserted = document.execCommand("insertText", false, flat);
      if (inserted) {
        editor.dispatchEvent(new InputEvent("input", { bubbles: true }));
      }
    } catch {
      /* fall through */
    }
    if (enough()) {
      return;
    }

    // Strategy 3: direct DOM, single paragraph.
    editor.innerHTML = "";
    const paragraph = document.createElement("p");
    paragraph.textContent = flat;
    editor.appendChild(paragraph);
    editor.dispatchEvent(
      new InputEvent("input", { bubbles: true, cancelable: true, inputType: "insertText", data: flat })
    );
    editor.dispatchEvent(new Event("change", { bubbles: true }));
  }

  async function pasteImage(editor, blob) {
    const ext = (blob.type.split("/")[1] || "png").replace("jpeg", "jpg");
    const file = new File([blob], `promptcard.${ext}`, { type: blob.type });
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add(file);
    editor.focus();
    const pasteEvent = new ClipboardEvent("paste", { bubbles: true, cancelable: true });
    try {
      Object.defineProperty(pasteEvent, "clipboardData", { value: dataTransfer });
    } catch {
      /* some engines lock clipboardData; ignore */
    }
    editor.dispatchEvent(pasteEvent);
  }

  function clickButton(button) {
    button.scrollIntoView({ block: "center" });
    for (const type of ["pointerover", "pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
      const Ctor = type.startsWith("pointer") ? PointerEvent : MouseEvent;
      button.dispatchEvent(new Ctor(type, { bubbles: true, cancelable: true, view: window }));
    }
  }

  function latestResponseText() {
    const nodes = document.querySelectorAll(selectors.response.join(","));
    if (!nodes.length) {
      return "";
    }
    const last = nodes[nodes.length - 1];

    // Prefer a code block: Gemini renders JSON inside <pre><code>, which keeps
    // the raw text clean (no "Copy" / "Use code with caution" chrome).
    const codeBlocks = last.querySelectorAll("pre code, code");
    for (let index = codeBlocks.length - 1; index >= 0; index -= 1) {
      const code = (codeBlocks[index].innerText || codeBlocks[index].textContent || "").trim();
      if (code.includes("{") && code.includes("}")) {
        return code;
      }
    }

    return (last.innerText || last.textContent || "").trim();
  }

  async function run() {
    const diag = { editorFound: false, editorText: 0, sendFound: false, sawGenerating: false };

    const editor = await waitFor(() => pickVisible(selectors.editor), timing.editorWaitMs, 300);
    if (!editor) {
      return { ok: false, error: "NOT_READY", message: "Could not find the chat input. Open the provider and sign in first.", diag };
    }
    diag.editorFound = true;

    if (!skipImage && base64) {
      const blob = base64ToBlob(base64, mimeType);
      await pasteImage(editor, blob);
      await sleep(timing.uploadSettleMs);
    }

    const wantsText = nonSpaceLen(promptText) > 0;
    diag.expectedText = promptText.length;

    if (wantsText) {
      setEditorText(editor, promptText);
      await sleep(500);
      const insertedText = readEditorText(editor);
      diag.editorText = insertedText.length;

      const targetChars = nonSpaceLen(promptText);
      if (nonSpaceLen(insertedText) < Math.floor(targetChars * 0.6)) {
        return {
          ok: false,
          error: "TEXT_NOT_SET",
          message: `Only part of the prompt reached the chat input (${diag.editorText}/${diag.expectedText} chars). The editor truncated the paste.`,
          diag
        };
      }
    } else {
      // GEM mode: the system prompt is embedded in the Gem, so we send the
      // image with no prompt text. Give the upload a moment to register.
      await sleep(800);
      diag.editorText = readEditorText(editor).length;
    }

    const sendButton = await waitFor(() => {
      const button = findButton(selectors.sendButton, selectors.sendIcons);
      return button && !isDisabled(button) ? button : null;
    }, timing.sendWaitMs, 300);

    if (!sendButton) {
      return {
        ok: false,
        error: "SEND_UNAVAILABLE",
        message: "The send button was not found or stayed disabled.",
        diag
      };
    }
    diag.sendFound = true;

    clickButton(sendButton);

    const startMarker = await waitFor(
      () => findButton(selectors.stopButton, selectors.stopIcons) || latestResponseText(),
      timing.responseStartMs,
      timing.pollMs
    );
    if (!startMarker) {
      return { ok: false, error: "NO_RESPONSE", message: "The provider did not start generating a response.", diag };
    }
    diag.sawGenerating = true;

    let lastText = "";
    let stableSince = Date.now();
    const deadline = Date.now() + timing.totalTimeoutMs;

    for (;;) {
      await sleep(timing.pollMs);
      const stopButton = findButton(selectors.stopButton, selectors.stopIcons);
      const text = latestResponseText();

      if (text && text !== lastText) {
        lastText = text;
        stableSince = Date.now();
      }

      const stoppedStreaming = !stopButton;
      const stableLongEnough = Date.now() - stableSince >= timing.stableMs;

      if (lastText && stoppedStreaming && stableLongEnough) {
        return { ok: true, text: lastText, diag };
      }

      if (Date.now() > deadline) {
        if (lastText) {
          return { ok: true, text: lastText, partial: true, diag };
        }
        return { ok: false, error: "TIMEOUT", message: "Timed out waiting for the provider response.", diag };
      }
    }
  }

  return run();
}

