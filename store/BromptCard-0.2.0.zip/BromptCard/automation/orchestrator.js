import { AnalysisError, parseAnalysisText, parseStyleText } from "../lib/schema.js";
import { imageTargetToPayload } from "../lib/image.js";
import { buildPromptText } from "../lib/prompt.js";
import { injectedAutomation } from "./inject.js";
import { getProvider, getProviderForMode } from "../providers/index.js";

const READY_TIMEOUT_MS = 12000;

function diagSuffix(diag) {
  if (!diag) {
    return "";
  }
  const steps = [
    `editor:${diag.editorFound ? "yes" : "no"}`,
    `text:${diag.editorText || 0}/${diag.expectedText || 0}`,
    `send:${diag.sendFound ? "yes" : "no"}`,
    `gen:${diag.sawGenerating ? "yes" : "no"}`
  ];
  return ` [${steps.join(" ")}]`;
}

function matchesProvider(provider, url) {
  if (!url) {
    return false;
  }
  return provider.urlPatterns.some((pattern) => {
    const regex = new RegExp(`^${pattern.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*")}$`);
    return regex.test(url);
  });
}

async function findProviderTab(provider) {
  const tabs = await chrome.tabs.query({});
  const matching = tabs.filter((tab) => matchesProvider(provider, tab.url));
  if (provider.matchUrl) {
    const exact = matching.find((tab) => (tab.url || "").includes(provider.matchUrl));
    if (exact) {
      return exact;
    }
  }
  return matching[0] || null;
}

async function ensureTabReady(tabId, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    const tab = await chrome.tabs.get(tabId);
    if (tab.status === "complete") {
      return tab;
    }
    if (Date.now() > deadline) {
      return tab;
    }
    await new Promise((resolve) => setTimeout(resolve, 400));
  }
}

async function openProviderTab(provider) {
  const tab = await chrome.tabs.create({ url: provider.homeUrl, active: false });
  await ensureTabReady(tab.id, READY_TIMEOUT_MS);
  await new Promise((resolve) => setTimeout(resolve, 2000));
  return tab;
}

async function startNewConversation(tabId, provider) {
  const tab = await chrome.tabs.get(tabId);
  const current = (tab.url || "");
  const onTarget = provider.matchUrl
    ? current.includes(provider.matchUrl)
    : current.replace(/\/+$/, "") === provider.homeUrl.replace(/\/+$/, "");
  if (onTarget) {
    await chrome.tabs.reload(tabId);
  } else {
    await chrome.tabs.update(tabId, { url: provider.homeUrl });
  }
  await ensureTabReady(tabId, READY_TIMEOUT_MS);
  await new Promise((resolve) => setTimeout(resolve, 2000));
}

async function runInTab(tabId, world, config) {
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    world,
    func: injectedAutomation,
    args: [config]
  });
  return result?.result;
}

export async function statusForProvider(providerId) {
  const provider = getProvider(providerId);
  const tab = await findProviderTab(provider);
  return {
    providerId: provider.id,
    providerName: provider.name,
    open: Boolean(tab),
    tabId: tab?.id || null
  };
}

export async function analyzeWithProvider(providerId, target, mode = "analyze") {
  const provider = mode && mode !== "analyze"
    ? getProviderForMode(mode)
    : getProvider(providerId);
  const payload = await imageTargetToPayload(target);

  let tab = await findProviderTab(provider);
  let openedHere = false;
  if (!tab) {
    tab = await openProviderTab(provider);
    openedHere = true;
  } else {
    await ensureTabReady(tab.id, READY_TIMEOUT_MS);
  }

  if (!tab?.id) {
    throw new AnalysisError(`Could not open ${provider.name}.`, "PROVIDER_TAB_FAILED");
  }

  const baseConfig = {
    base64: payload.data,
    mimeType: payload.mimeType,
    selectors: provider.selectors,
    timing: provider.timing
  };

  // One analysis = one send. Always start fresh on the target page (a GEM that
  // already embeds the system prompt, or a normal chat) with the image attached.
  // When the provider uses a GEM, we send the image alone with no prompt text.
  const usesGem = provider.sendPrompt === false;

  // GEM mode sends the image alone: the Gem already embeds the full system prompt.
  const promptText = usesGem ? "" : buildPromptText(target);

  if (!openedHere) {
    await startNewConversation(tab.id, provider);
  }

  const result = await runInTab(tab.id, provider.world, {
    ...baseConfig,
    promptText
  });

  if (!result) {
    throw new AnalysisError(`${provider.name} automation did not return a result.`, "AUTOMATION_FAILED");
  }
  if (!result.ok) {
    const code = result.error || "AUTOMATION_FAILED";
    const hint = openedHere
      ? ` A new ${provider.name} tab was opened; sign in there and try again.`
      : "";
    throw new AnalysisError((result.message || "Automation failed.") + hint + diagSuffix(result.diag), code);
  }

  return mode === "style" ? parseStyleText(result.text) : parseAnalysisText(result.text);
}



