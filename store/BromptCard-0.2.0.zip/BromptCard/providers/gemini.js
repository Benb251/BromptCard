const GEMINI_SELECTORS = {
  editor: [
    "rich-textarea .ql-editor[contenteditable='true']",
    "div.ql-editor[contenteditable='true']",
    "div[contenteditable='true'][role='textbox']",
    "div[contenteditable='true']",
    "textarea[aria-label]"
  ],
  sendButton: [
    "button.send-button",
    "button[aria-label='Send message']",
    "button[aria-label*='Send']",
    "button[aria-label*='Gửi']",
    "button[mattooltip*='Send']",
    "button[mattooltip*='Gửi']"
  ],
  sendIcons: ["send"],
  stopButton: [
    "button.send-button.stop",
    "button[aria-label='Stop response']",
    "button[aria-label*='Stop']",
    "button[aria-label*='Dừng']",
    "button[aria-label*='Ngừng']"
  ],
  stopIcons: ["stop"],
  response: [
    "message-content.model-response-text",
    "model-response .markdown",
    ".model-response-text .markdown",
    "message-content .markdown",
    "model-response message-content",
    "[id^='model-response-message-content']"
  ]
};

const GEMINI_TIMING = {
  totalTimeoutMs: 180000,
  editorWaitMs: 15000,
  uploadSettleMs: 4000,
  sendWaitMs: 30000,
  responseStartMs: 25000,
  pollMs: 600,
  stableMs: 2200
};

function geminiGem(id, name, gemPath) {
  return {
    id,
    name,
    homeUrl: `https://gemini.google.com/gem/${gemPath}?usp=sharing`,
    urlPatterns: ["https://gemini.google.com/*"],
    matchUrl: `gem/${gemPath}`,
    sendPrompt: false,
    world: "MAIN",
    selectors: GEMINI_SELECTORS,
    timing: GEMINI_TIMING
  };
}

// Reverse-prompt GEM (default analyze mode).
export const GEMINI_PROVIDER = geminiGem(
  "gemini",
  "Gemini",
  "1xenoseg-iGYrqrhDhQtHyWuuFrF371-2"
);

// Style-extraction GEM (style mode).
export const GEMINI_STYLE_PROVIDER = geminiGem(
  "gemini_style",
  "Gemini Style",
  "1Jo12L932iGCg1XQuJj95sQEseFwUCiy4"
);
