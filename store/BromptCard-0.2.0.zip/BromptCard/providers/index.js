import { GEMINI_PROVIDER, GEMINI_STYLE_PROVIDER } from "./gemini.js";

export const PROVIDERS = {
  [GEMINI_PROVIDER.id]: GEMINI_PROVIDER,
  [GEMINI_STYLE_PROVIDER.id]: GEMINI_STYLE_PROVIDER
};

export const PROVIDER_LIST = Object.values(PROVIDERS);

export const DEFAULT_PROVIDER_ID = GEMINI_PROVIDER.id;

// Maps an analysis mode to the provider that handles it.
export const MODE_PROVIDER = {
  analyze: GEMINI_PROVIDER.id,
  style: GEMINI_STYLE_PROVIDER.id
};

export function getProvider(id) {
  return PROVIDERS[id] || PROVIDERS[DEFAULT_PROVIDER_ID];
}

export function getProviderForMode(mode) {
  const id = MODE_PROVIDER[mode] || DEFAULT_PROVIDER_ID;
  return PROVIDERS[id];
}
