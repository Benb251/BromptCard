import { DEFAULT_SETTINGS } from "./constants.js";
import { PROVIDERS, DEFAULT_PROVIDER_ID } from "./providers/index.js";

export async function getSettings() {
  const stored = await chrome.storage.local.get(["provider", "language"]);
  const provider =
    typeof stored.provider === "string" && PROVIDERS[stored.provider]
      ? stored.provider
      : DEFAULT_PROVIDER_ID;
  return {
    provider,
    language: typeof stored.language === "string" ? stored.language : DEFAULT_SETTINGS.language
  };
}

export async function saveSettings(partial) {
  const current = await getSettings();
  const next = { ...current };

  if (typeof partial.provider === "string" && PROVIDERS[partial.provider]) {
    next.provider = partial.provider;
  }
  if (typeof partial.language === "string") {
    next.language = partial.language;
  }

  await chrome.storage.local.set({
    provider: next.provider,
    language: next.language
  });
  return next;
}
